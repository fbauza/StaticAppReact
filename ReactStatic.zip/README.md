# React-Static - Basic Template

To use this template, run `react-static create` and use the `basic` template.
