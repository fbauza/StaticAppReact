


// Template Map
export default {
  '__react_static_root__/src/pages/404.js': require('__react_static_root__/src/pages/404.js').default,
'__react_static_root__/src/pages/about.js': require('__react_static_root__/src/pages/about.js').default,
'__react_static_root__/src/pages/blog.js': require('__react_static_root__/src/pages/blog.js').default,
'__react_static_root__/src/pages/index.js': require('__react_static_root__/src/pages/index.js').default,
'__react_static_root__/src/containers/Post': require('__react_static_root__/src/containers/Post').default
}

export const notFoundTemplate = '__react_static_root__/src/pages/404.js'

