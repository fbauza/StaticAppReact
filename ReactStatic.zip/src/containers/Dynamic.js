import React from 'react'

export default () => (
  <div>
    This is a dynamic page! It will not be statically exported, but is available
    at runtime
  </div>
)
