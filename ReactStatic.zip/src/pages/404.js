import React from 'react'

export default () => (
  <div>
    <h1>404 - Oh no's! We couldn't find that page :(</h1>
  </div>
)
